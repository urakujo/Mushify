package com.mushify.app.onboarding.screens;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.mushify.app.R;

public class ThirdScreen extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_third_screen, container, false);

        TextView finishButton = view.findViewById(R.id.finish);
        finishButton.setOnClickListener(v -> {
            onBoardingFinished();
            FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
            Fragment fragment = fragmentManager.findFragmentById(R.id.tips_frame);

            if (fragment != null) {
                fragmentManager.beginTransaction()
                        .remove(fragment)
                        .commit();
            }
            requireActivity().findViewById(R.id.tips_frame).setVisibility(View.GONE);
            requireActivity().findViewById(R.id.cl).setVisibility(View.VISIBLE);

        });

        return view;
    }

    private void onBoardingFinished() {
        SharedPreferences sharedPref = requireActivity().getSharedPreferences("onBoarding", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();
        editor.putBoolean("Finished", true);
        editor.apply();
    }
}