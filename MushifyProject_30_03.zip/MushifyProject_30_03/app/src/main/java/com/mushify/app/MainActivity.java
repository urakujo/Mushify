package com.mushify.app;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.mushify.app.onboarding.ViewPagerFragment;

public class MainActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("tips")) {
            if (intent.getStringExtra("tips").equals("yes")) {
                findViewById(R.id.tips_frame).setVisibility(View.VISIBLE);
                getSupportFragmentManager().beginTransaction().replace(R.id.tips_frame, new ViewPagerFragment()).commit();
            }
        }
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new Main())
                .commit();
    }



    public void goToCameraFragment(View view) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new Main())
                .commit();
    }
}