package com.mushify.app;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class ActivitySplash extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (onBoardingFinished()) {
                startActivity(new Intent(ActivitySplash.this, MainActivity.class));
            } else {
                Intent intent = new Intent(ActivitySplash.this, MainActivity.class);
                intent.putExtra("tips", "yes");
                startActivity(intent);
            }
        }, 3000);
    }

    private boolean onBoardingFinished() {
        SharedPreferences sharedPref = getSharedPreferences("onBoarding", Context.MODE_PRIVATE);
        return sharedPref.getBoolean("Finished", false);
    }
}
