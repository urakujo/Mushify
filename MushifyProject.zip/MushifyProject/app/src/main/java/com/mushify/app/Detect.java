package com.mushify.app;

import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.tensorflow.lite.Interpreter;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class Detect extends Fragment {
    private static final int IMG_SIZE = 224;
    private static final String MODEL_NAME = "model_unquant.tflite";
    private static final String PATH_NAME = "converted_tflite (29)";
    private Interpreter tflite;
    private ImageButton button_back;
    private TextView textView;
    private ImageView imageView;
    private Button saveButton;
    private Bitmap image;
    private String predictedMushroomName;
    private MushroomDatabaseHelper dbHelper;
    private boolean isSaving = false;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_detect, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        button_back = view.findViewById(R.id.back_btn);
        imageView = view.findViewById(R.id.imageView);
        textView = view.findViewById(R.id.textView);
        saveButton = view.findViewById(R.id.save_btn);
        saveButton.setClickable(true);
        dbHelper = new MushroomDatabaseHelper(requireContext());

        Bundle args = getArguments();
        String imagePath = args.getString("image_path");
        if (imagePath != null) {
            image = BitmapFactory.decodeFile(imagePath);
            imageView.setImageBitmap(image);
        }

        button_back.setOnClickListener(v -> getParentFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new Main())
                .commit());

        saveButton.setOnClickListener(null);
        saveButton.setOnClickListener(v -> {
            if (!isSaving) {
                Log.d("Mushify", "Save button clicked");
                saveMushroomData();
            } else {
                Toast.makeText(requireContext(), "Saving in progress", Toast.LENGTH_SHORT).show();
            }
        });

        if (image != null) {
            try {
                tflite = new Interpreter(loadModelFile());
                List<String> classNames = loadClassNamesFromAssets();
                runDetection(image, classNames);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void saveMushroomData() {
        Log.d("Mushify", "Starting saveMushroomData");
        if (isSaving) {
            Log.d("Mushify", "Already saving, aborting");
            return;
        }
        isSaving = true;
        saveButton.setEnabled(false);
        saveButton.setClickable(false);

        if (image == null || predictedMushroomName == null || predictedMushroomName.equals("notafungus")) {
            Log.d("Mushify", "Invalid data: image=" + (image == null) + ", name=" + predictedMushroomName);
            Toast.makeText(requireContext(), "No valid mushroom data", Toast.LENGTH_SHORT).show();
            isSaving = false;
            saveButton.setEnabled(true);
            saveButton.setClickable(true);
            return;
        }

        String date = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
        String fileName = "mushroom_" + System.currentTimeMillis() + ".jpg";
        File imageFile = new File(requireContext().getFilesDir(), fileName);
        Log.d("Mushify", "Saving image to: " + imageFile.getAbsolutePath());

        try (FileOutputStream fos = new FileOutputStream(imageFile)) {
            image.compress(Bitmap.CompressFormat.JPEG, 80, fos);
            Log.d("Mushify", "Image saved, size: " + imageFile.length() / 1024 + " KB");
        } catch (IOException e) {
            Log.e("Storage", "Error saving image", e);
            saveButton.setText("Failed to save image");
            Toast.makeText(requireContext(), "Failed to save image", Toast.LENGTH_SHORT).show();
            isSaving = false;
            saveButton.setEnabled(true);
            saveButton.setClickable(true);
            return;
        }

        dbHelper.addMushroom(predictedMushroomName, date, imageFile.getAbsolutePath());
        Log.d("Mushify", "Saved to SQLite: name=" + predictedMushroomName);
        saveButton.setText("Mushroom saved");
        Toast.makeText(requireContext(), "Mushroom saved", Toast.LENGTH_SHORT).show();
        isSaving = false;
        saveButton.setEnabled(false);
        saveButton.setClickable(false);
        image = null;
        predictedMushroomName = null;
    }

    private List<String> loadClassNamesFromAssets() throws IOException {
        List<String> classNames = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(requireContext().getAssets().open(PATH_NAME + "/labels.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split(" ", 2);
                if (parts.length == 2) {
                    classNames.add(parts[1]);
                }
            }
        }
        return classNames;
    }

    private MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor = requireContext().getAssets().openFd(PATH_NAME + "/" + MODEL_NAME);
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);
    }

    private ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * IMG_SIZE * IMG_SIZE * 3);
        byteBuffer.order(ByteOrder.nativeOrder());

        int[] intValues = new int[IMG_SIZE * IMG_SIZE];
        bitmap.getPixels(intValues, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());

        for (int pixel : intValues) {
            float r = ((pixel >> 16) & 0xFF) / 255.0f;
            float g = ((pixel >> 8) & 0xFF) / 255.0f;
            float b = (pixel & 0xFF) / 255.0f;
            byteBuffer.putFloat(r);
            byteBuffer.putFloat(g);
            byteBuffer.putFloat(b);
        }
        return byteBuffer;
    }

    private Bitmap centerCropBitmap(Bitmap srcBmp) {
        int dimension = Math.min(srcBmp.getWidth(), srcBmp.getHeight());
        int x = (srcBmp.getWidth() - dimension) / 2;
        int y = (srcBmp.getHeight() - dimension) / 2;
        return Bitmap.createBitmap(srcBmp, x, y, dimension, dimension);
    }

    private int getMaxIndex(float[] array) {
        int maxIndex = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    private int getSecondIndex(float[] array, int maxI) {
        int secondIndex = -1;
        for (int i = 0; i < array.length; i++) {
            if (i == maxI) continue;
            if (secondIndex == -1 || array[i] > array[secondIndex]) {
                secondIndex = i;
            }
        }
        return secondIndex;
    }

    private void runDetection(Bitmap bitmap, List<String> classNames) {
        Bitmap croppedBitmap = centerCropBitmap(bitmap);
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(croppedBitmap, IMG_SIZE, IMG_SIZE, true);

        ByteBuffer inputBuffer = convertBitmapToByteBuffer(resizedBitmap);

        float[][] output = new float[1][classNames.size()];
        tflite.run(inputBuffer, output);

        int predictedClass1Index = getMaxIndex(output[0]);
        int predictedClass2Index = getSecondIndex(output[0], predictedClass1Index);

        double chances1 = output[0][predictedClass1Index] * 100.0;
        double chances2 = output[0][predictedClass2Index] * 100.0;

        String predictedClass1 = classNames.get(predictedClass1Index);
        String predictedClass2 = classNames.get(predictedClass2Index);

        predictedMushroomName = predictedClass1;

        if (predictedClass1.equals("notafungus")) {
            textView.setText("It's not a mushroom.");
            saveButton.setVisibility(View.GONE);
        } else if (!predictedClass1.equals("notafungus") && (predictedClass2.equals("notafungus") || chances2 < 1)) {
            saveButton.setVisibility(View.VISIBLE);
            textView.setText(predictedClass1 + " - " + String.format("%.1f", chances1) + "%");
        } else {
            saveButton.setVisibility(View.VISIBLE);
            textView.setText(predictedClass1 + " - " + String.format("%.1f", chances1) + "%\n" +
                    predictedClass2 + " - " + String.format("%.1f", chances2) + "%");
        }
    }
}