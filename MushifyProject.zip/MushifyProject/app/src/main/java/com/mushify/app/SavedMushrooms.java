package com.mushify.app;

import android.app.Dialog;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class SavedMushrooms extends Fragment {
    private RecyclerView recyclerView;
    private MushroomDatabaseHelper dbHelper;
    private MushroomAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_saved_mushrooms, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        requireActivity().findViewById(R.id.cl).setVisibility(View.GONE);

        recyclerView = view.findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        dbHelper = new MushroomDatabaseHelper(requireContext());
        loadMushrooms();

        view.findViewById(R.id.back_btn).setOnClickListener(v -> {
            requireActivity().findViewById(R.id.cl).setVisibility(View.VISIBLE);
            getParentFragmentManager().popBackStack();
        });
    }

    private void loadMushrooms() {
        Log.d("Mushify", "Fetching mushrooms from SQLite");
        Cursor cursor = dbHelper.getAllMushrooms();
        List<Mushroom> mushrooms = new ArrayList<>();
        if (cursor.moveToFirst()) {
            int nameIndex = cursor.getColumnIndex("name");
            int dateIndex = cursor.getColumnIndex("date");
            int pathIndex = cursor.getColumnIndex("image_path");
            do {
                mushrooms.add(new Mushroom(
                        cursor.getString(nameIndex),
                        cursor.getString(dateIndex),
                        cursor.getString(pathIndex)
                ));
            } while (cursor.moveToNext());
        }
        cursor.close();
        adapter = new MushroomAdapter(this, mushrooms);
        recyclerView.setAdapter(adapter);
        if (mushrooms.isEmpty()) {
            Toast.makeText(requireContext(), "No mushrooms found", Toast.LENGTH_SHORT).show();
        }
    }

    public void showMushroomDialog(Mushroom mushroom) {
        Dialog dialog = new Dialog(requireContext());
        dialog.setContentView(R.layout.dialog_mushroom_details);
        dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);

        ImageView fullImage = dialog.findViewById(R.id.fullImage);
        TextView fullName = dialog.findViewById(R.id.fullName);
        TextView fullDate = dialog.findViewById(R.id.fullDate);

        Bitmap bitmap = BitmapFactory.decodeFile(mushroom.imagePath);
        if (bitmap != null) {
            fullImage.setImageBitmap(bitmap);
        } else {
            Log.w("Mushify", "Failed to load image: " + mushroom.imagePath);
        }
        fullName.setText(mushroom.name);
        fullDate.setText(mushroom.date);

        dialog.show();
    }

    private void deleteMushroom(Mushroom mushroom, int position) {
        // Delete image file
        File imageFile = new File(mushroom.imagePath);
        if (imageFile.exists() && imageFile.delete()) {
            Log.d("Mushify", "Deleted image: " + mushroom.imagePath);
        } else {
            Log.w("Mushify", "Failed to delete image: " + mushroom.imagePath);
        }

        // Delete from SQLite
        dbHelper.deleteMushroom(mushroom.imagePath);

        // Update RecyclerView
        adapter.removeMushroom(position);
        Toast.makeText(requireContext(), "Mushroom deleted", Toast.LENGTH_SHORT).show();
    }

    private static class Mushroom {
        String name;
        String date;
        String imagePath;

        Mushroom(String name, String date, String imagePath) {
            this.name = name;
            this.date = date;
            this.imagePath = imagePath;
        }
    }

    private static class MushroomAdapter extends RecyclerView.Adapter<MushroomViewHolder> {
        private final SavedMushrooms fragment;
        private final List<Mushroom> mushrooms;

        MushroomAdapter(SavedMushrooms fragment, List<Mushroom> mushrooms) {
            this.fragment = fragment;
            this.mushrooms = mushrooms;
        }

        @NonNull
        @Override
        public MushroomViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_mushroom, parent, false);
            return new MushroomViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull MushroomViewHolder holder, int position) {
            Mushroom mushroom = mushrooms.get(position);
            holder.nameTextView.setText(mushroom.name);
            holder.dateTextView.setText(mushroom.date);
            Bitmap bitmap = BitmapFactory.decodeFile(mushroom.imagePath);
            if (bitmap != null) {
                holder.imageView.setImageBitmap(bitmap);
            } else {
                Log.w("Mushify", "Failed to load image: " + mushroom.imagePath);
            }
            holder.itemView.setOnClickListener(v -> fragment.showMushroomDialog(mushroom));
            holder.deleteButton.setOnClickListener(v -> fragment.deleteMushroom(mushroom, position));
        }

        @Override
        public int getItemCount() {
            return mushrooms.size();
        }

        void removeMushroom(int position) {
            mushrooms.remove(position);
            notifyItemRemoved(position);
            notifyItemRangeChanged(position, mushrooms.size());
        }
    }

    private static class MushroomViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView nameTextView;
        TextView dateTextView;
        ImageButton deleteButton;

        MushroomViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.mushroomImage);
            nameTextView = itemView.findViewById(R.id.mushroomName);
            dateTextView = itemView.findViewById(R.id.mushroomDate);
            deleteButton = itemView.findViewById(R.id.deleteButton);
        }
    }
}