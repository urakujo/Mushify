package com.mushify.app.onboarding;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager2.widget.ViewPager2;

import com.mushify.app.R;
import com.mushify.app.onboarding.screens.FirstScreen;
import com.mushify.app.onboarding.screens.SecondScreen;
import com.mushify.app.onboarding.screens.ThirdScreen;

import java.util.ArrayList;

public class ViewPagerFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_pager, container, false);
        requireActivity().findViewById(R.id.cl).setVisibility(View.GONE);

        ArrayList<Fragment> fragmentList = new ArrayList<>();
        fragmentList.add(new FirstScreen());
        fragmentList.add(new SecondScreen());
        fragmentList.add(new ThirdScreen());

        FragmentManager fragmentManager = requireActivity().getSupportFragmentManager();
        Lifecycle lifecycle = getLifecycle();
        ViewPagerAdapter adapter = new ViewPagerAdapter(fragmentList, fragmentManager, lifecycle);

        ViewPager2 vp = view.findViewById(R.id.viewPager);
        vp.setAdapter(adapter);

        return view;
    }
}
