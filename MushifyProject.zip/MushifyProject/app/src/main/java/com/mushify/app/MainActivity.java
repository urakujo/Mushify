package com.mushify.app;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.mushify.app.onboarding.ViewPagerFragment;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ensure cl is visible initially
        findViewById(R.id.cl).setVisibility(View.VISIBLE);

        // Handle onboarding
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("tips") && intent.getStringExtra("tips").equals("yes")) {
            findViewById(R.id.tips_frame).setVisibility(View.VISIBLE);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.tips_frame, new ViewPagerFragment())
                    .commit();
        }

        // Load initial Main fragment
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new Main())
                .commit();

        // Saved Mushrooms button
        findViewById(R.id.saved_mushrooms).setOnClickListener(v -> {
            findViewById(R.id.cl).setVisibility(View.GONE);
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.frame_layout, new SavedMushrooms())
                    .addToBackStack(null)
                    .commit();
        });
    }

    public void goToCameraFragment(View view) {
        findViewById(R.id.cl).setVisibility(View.VISIBLE);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new Main()) // Replace with your actual camera fragment
                .addToBackStack(null)
                .commit();
    }
}