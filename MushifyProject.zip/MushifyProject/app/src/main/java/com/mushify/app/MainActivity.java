package com.mushify.app;


import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new Main())
                .commit();
    }

    public void goToCameraFragment(View view) {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.frame_layout, new Main())
                .commit();
    }
}