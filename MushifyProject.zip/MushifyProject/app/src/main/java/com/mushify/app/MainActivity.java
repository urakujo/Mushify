package com.mushify.app;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.media.Image;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.camera.core.AspectRatio;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.ImageProxy;
import androidx.camera.core.Preview;
import androidx.camera.core.TorchState;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.android.material.button.MaterialButton;
import com.google.common.util.concurrent.ListenableFuture;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;


public class MainActivity extends AppCompatActivity {
    ImageButton capture, flash, gallery, retakeBtn;
    Bitmap taken_image;
    MaterialButton pick_btn;
    private PreviewView preview;
    int cameraFacing = CameraSelector.LENS_FACING_BACK;
    ActivityResultLauncher<String> activityResultLauncher, activityResultLauncherStorage;
    private void openGallery() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(intent, 15);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        pick_btn = findViewById(R.id.pick_btn);
        String permission = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_IMAGES : Manifest.permission.READ_EXTERNAL_STORAGE;


        pick_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                File cacheDir = getCacheDir();
                File tempFile = new File(cacheDir, "temp_image.png");

                try (FileOutputStream fos = new FileOutputStream(tempFile)) {
                    taken_image.compress(Bitmap.CompressFormat.JPEG, 100, fos);  // using jpeg 'cuz png makes freezes on old devices
                } catch (IOException e) {
                    e.printStackTrace();
                }

                Intent intent = new Intent(MainActivity.this, DetectActivity.class);
                intent.putExtra("image_path", tempFile.getAbsolutePath());  // putting temporary file's path into the intent
                startActivity(intent);
            }
        });


        capture = findViewById(R.id.capture);
        flash = findViewById(R.id.flash);
        preview = findViewById(R.id.preview);
        retakeBtn = findViewById(R.id.retake);
        gallery = findViewById(R.id.gallery);

        // making an object to ask for permissions
        activityResultLauncher = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), result -> {
                    if (result) {
                        startCamera(cameraFacing);
                    } else {
                        preview.setVisibility(View.GONE);
                        ImageView imageView = findViewById(R.id.imageView);
                        imageView.setImageDrawable(ContextCompat.getDrawable(MainActivity.this, R.drawable.permission_req));
                        imageView.setVisibility(View.VISIBLE);

                        capture.setEnabled(false);
                        flash.setEnabled(false);
                        capture.setVisibility(View.GONE);
                        flash.setVisibility(View.GONE);
                        Toast.makeText(this, "Camera permission is required", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        activityResultLauncherStorage = registerForActivityResult(
                new ActivityResultContracts.RequestPermission(), result -> {
                    if (result) {
                        openGallery();
                    } else {
                        Toast.makeText(MainActivity.this, "Storage usage permission is required", Toast.LENGTH_SHORT).show();
                    }
                }
        );

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            activityResultLauncher.launch(Manifest.permission.CAMERA);
        } else {
            startCamera(cameraFacing);
        }


        retakeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    activityResultLauncher.launch(Manifest.permission.CAMERA);
                    gallery.setEnabled(true);
                    retakeBtn.setEnabled(false);
                    retakeBtn.setVisibility(View.GONE);
                    gallery.setVisibility(View.VISIBLE);
                    restartCamera();
                } else {
                    preview.setVisibility(View.VISIBLE);
                    ImageView imageView = findViewById(R.id.imageView);
                    imageView.setVisibility(View.GONE);

                    capture.setEnabled(true);
                    flash.setEnabled(true);
                    gallery.setEnabled(true);
                    retakeBtn.setEnabled(false);
                    pick_btn.setEnabled(false);
                    retakeBtn.setVisibility(View.GONE);
                    pick_btn.setVisibility(View.GONE);
                    capture.setVisibility(View.VISIBLE);
                    flash.setVisibility(View.VISIBLE);
                    gallery.setVisibility(View.VISIBLE);
                    restartCamera();
                }

            }
        });

        gallery.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, permission)
                        != PackageManager.PERMISSION_GRANTED) {
                    activityResultLauncherStorage.launch(permission);
                } else {
                    openGallery();
                }
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == 15 && data != null) {
            Uri selected_image = data.getData();
            taken_image = getBitmapFromUri(selected_image, MainActivity.this);
            preview.setVisibility(View.GONE);
            ImageView imageView = findViewById(R.id.imageView);
            imageView.setImageURI(selected_image);
            imageView.setVisibility(View.VISIBLE);

            capture.setEnabled(false);
            flash.setEnabled(false);
            gallery.setEnabled(false);
            capture.setVisibility(View.GONE);
            flash.setVisibility(View.GONE);
            gallery.setVisibility(View.GONE);
            retakeBtn.setEnabled(true);
            pick_btn.setEnabled(true);
            retakeBtn.setVisibility(View.VISIBLE);
            pick_btn.setVisibility(View.VISIBLE);
        }
    }

    public Bitmap getBitmapFromUri(Uri uri, Context context) {
        Bitmap bitmap = null;
        try {
            ContentResolver contentResolver = context.getContentResolver();

            InputStream inputStream = contentResolver.openInputStream(uri);

            if (inputStream != null) {
                bitmap = BitmapFactory.decodeStream(inputStream);
                inputStream.close();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return bitmap;
    }

    private void restartCamera() {
        ProcessCameraProvider cameraProvider = getCameraProvider();
        if (cameraProvider != null) {
            cameraProvider.unbindAll();

            startCamera(cameraFacing);
        }
    }

    private ProcessCameraProvider getCameraProvider() {
        try {
            ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);
            return cameraProviderFuture.get();
        } catch (ExecutionException | InterruptedException e) {
            e.printStackTrace();
            return null;
        }
    }

    public void startCamera(int cameraFacing) {

        preview.setVisibility(View.VISIBLE);
        ImageView imageView = findViewById(R.id.imageView);
        imageView.setVisibility(View.GONE);

        capture.setEnabled(true);
        flash.setEnabled(true);
        gallery.setEnabled(true);
        retakeBtn.setEnabled(false);
        pick_btn.setEnabled(false);
        retakeBtn.setVisibility(View.GONE);
        pick_btn.setVisibility(View.GONE);
        capture.setVisibility(View.VISIBLE);
        flash.setVisibility(View.VISIBLE);
        gallery.setVisibility(View.VISIBLE);

        int aspectRatio = getRatio(preview.getWidth(), preview.getHeight());

        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);
        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider processCameraProvider = cameraProviderFuture.get();  // camera lyfecycle

                CameraSelector cameraSelector = new CameraSelector.Builder().requireLensFacing(cameraFacing).build();  // camera facing

                Preview preview1 = new Preview.Builder().setTargetAspectRatio(aspectRatio).build();  // preview where we can see camera

                ImageCapture imageCapture = new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY)
                        .setTargetRotation(getWindowManager().getDefaultDisplay().getRotation()).build();  // camera's parameters

                processCameraProvider.unbindAll();  // unbinding everything from current lyfecycle

                Camera camera = processCameraProvider.bindToLifecycle(this, cameraSelector, preview1, imageCapture);  // and binding this cammra

                capture.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        takePicture(imageCapture);
                    }
                });

                flash.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        setFlash(camera);
                    }
                });


                preview1.setSurfaceProvider(preview.getSurfaceProvider());
            } catch (ExecutionException | InterruptedException e) {
                e.printStackTrace();
            }
        }, ContextCompat.getMainExecutor(this));
    }

    public void takePicture(ImageCapture imageCapture) {
        imageCapture.takePicture(Executors.newSingleThreadExecutor(), new ImageCapture.OnImageCapturedCallback() {
            @Override
            public void onCaptureSuccess(@NonNull ImageProxy imageProxy) {
                Bitmap bitmap = imageProxyToBitmap(imageProxy);
                taken_image = bitmap;
                imageProxy.close();

                runOnUiThread(() -> {
                    preview.setVisibility(View.GONE);
                    ImageView imageView = findViewById(R.id.imageView);
                    imageView.setImageBitmap(bitmap);
                    imageView.setVisibility(View.VISIBLE);

                    capture.setEnabled(false);
                    flash.setEnabled(false);
                    gallery.setEnabled(false);
                    capture.setVisibility(View.GONE);
                    flash.setVisibility(View.GONE);
                    gallery.setVisibility(View.GONE);
                    retakeBtn.setEnabled(true);
                    pick_btn.setEnabled(true);
                    retakeBtn.setVisibility(View.VISIBLE);
                    pick_btn.setVisibility(View.VISIBLE);
                });
            }

            @Override
            public void onError(@NonNull ImageCaptureException exception) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Error capturing photo: " + exception.getMessage(), Toast.LENGTH_SHORT).show());
            }
        });
    }

    private Bitmap imageProxyToBitmap(ImageProxy imageProxy) {
        @SuppressLint("UnsafeOptInUsageError")
        Image image = imageProxy.getImage();
        if (image != null) {
            ByteBuffer buffer = image.getPlanes()[0].getBuffer();
            byte[] bytes = new byte[buffer.remaining()];
            buffer.get(bytes);
            Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);

            int rotationDegrees = imageProxy.getImageInfo().getRotationDegrees();

            Matrix matrix = new Matrix();
            matrix.postRotate(rotationDegrees);
            return Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, true);
        }
        return null;
    }


    public void setFlash(Camera camera) {
        if (camera.getCameraInfo().hasFlashUnit()) {
            boolean isFlashOn = camera.getCameraInfo().getTorchState().getValue() == TorchState.ON;
            if (isFlashOn) {
                camera.getCameraControl().enableTorch(false);
                flash.setImageDrawable(AppCompatResources.getDrawable(MainActivity.this, R.drawable.flash_off));
            }
            else {
                camera.getCameraControl().enableTorch(true);
                flash.setImageDrawable(AppCompatResources.getDrawable(MainActivity.this, R.drawable.flash_on));
            }
        } else {
            Toast.makeText(this, "Flash is not available", Toast.LENGTH_SHORT).show();
        }
    }

    private int getRatio(int width, int height) {
        double previewRatio = (double) Math.max(width, height) / Math.min(width, height);
        if (Math.abs(previewRatio - 4.0 / 3.0) <= Math.abs(previewRatio - 16.0 / 9.0)) {
            return AspectRatio.RATIO_4_3;
        }
        return AspectRatio.RATIO_16_9;
    }
}