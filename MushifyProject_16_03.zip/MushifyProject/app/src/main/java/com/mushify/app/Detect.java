package com.mushify.app;

import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import org.tensorflow.lite.Interpreter;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Detect extends Fragment {
    private static final int IMG_SIZE = 224;
    private static final String MODEL_NAME = "model_unquant.tflite";
    private static final String PATH_NAME = "converted_tflite_16_05";
    private Interpreter tflite;  // interpreter that
    ImageButton button_back;
    TextView textView;
    ImageView imageView;
    private Bitmap image;
    double sum;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_detect, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        button_back = view.findViewById(R.id.back_btn);
        imageView = view.findViewById(R.id.imageView);
        textView = view.findViewById(R.id.textView);

        Bundle args = getArguments();
        String imagePath = args.getString("image_path");
        if (imagePath != null) {
            image = BitmapFactory.decodeFile(imagePath);  // getting image from temporary files
            imageView.setImageBitmap(image);
        }

        button_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getParentFragmentManager().beginTransaction()
                        .replace(R.id.frame_layout, new Main())
                        .commit();
            }
        });

        if (image != null) {
            try {
                tflite = new Interpreter(loadModelFile());  // loading model

                List<String> classNames = loadClassNamesFromAssets();  // getting class names from label.txt

                runDetection(image, classNames);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private List<String> loadClassNamesFromAssets() throws IOException {
        List<String> classNames = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(
                new InputStreamReader(requireContext().getAssets().open(PATH_NAME + "/labels.txt")))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.trim().split(" ", 2); // split only at the first space
                if (parts.length == 2) {
                    classNames.add(parts[1]);
                }
            }
        }
        return classNames;
    }


    private MappedByteBuffer loadModelFile() throws IOException {
        AssetFileDescriptor fileDescriptor = requireContext().getAssets().openFd(PATH_NAME + "/" + MODEL_NAME);  // this thing contains information about model
        FileInputStream inputStream = new FileInputStream(fileDescriptor.getFileDescriptor());  // inputstream to read model's data
        FileChannel fileChannel = inputStream.getChannel();
        long startOffset = fileDescriptor.getStartOffset();
        long declaredLength = fileDescriptor.getDeclaredLength();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, startOffset, declaredLength);  // getting model as mappedbytebuffer
    }

    private ByteBuffer convertBitmapToByteBuffer(Bitmap bitmap) {  // converting bitmap into bytes cuz tensorflow works like that
        ByteBuffer byteBuffer = ByteBuffer.allocateDirect(4 * IMG_SIZE * IMG_SIZE * 3);  // giving place in the memory
        // 4 for the float(it takes 4 bytes), imgs.*imgs. that's the bites of our square image and 3 is for the rgb channels that every byte has
        byteBuffer.order(ByteOrder.nativeOrder());
        int[] intValues = new int[IMG_SIZE * IMG_SIZE];
        bitmap.getPixels(intValues, 0, bitmap.getWidth(), 0, 0, bitmap.getWidth(), bitmap.getHeight());
        // getting the bytes above


        for (int i = 0; i < intValues.length; i++) {
            int pixel = intValues[i];
            byteBuffer.putFloat(((pixel >> 16) & 0xFF) / 255.0f);
            byteBuffer.putFloat(((pixel >> 8) & 0xFF) / 255.0f);
            byteBuffer.putFloat((pixel & 0xFF) / 255.0f);
            // normalization of the bytes(idk how it works and why, i haven't understood this part, this function was copied)
        }

        return byteBuffer;
    }

    private int getMaxIndex(float[] array) {  // basically getting index of the class who got the most probability
        int maxIndex = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[maxIndex]) {
                maxIndex = i;
            }
        }
        return maxIndex;
    }

    private int getSecondIndex(float[] array, int maxI) {  // basically getting index of the class who got the most probability
        int secondIndex = 0;
        for (int i = 1; i < array.length; i++) {
            if (array[i] > array[secondIndex] && i != maxI) {
                secondIndex = i;
            }
        }
        return secondIndex;
    }

    private void runDetection(Bitmap bitmap, List<String> classNames) {
        Bitmap resizedBitmap = Bitmap.createScaledBitmap(bitmap, IMG_SIZE, IMG_SIZE, false);  // resizing image to the size which was used to train the model(224x224)
        ByteBuffer inputBuffer = convertBitmapToByteBuffer(resizedBitmap);

        float[][] output = new float[1][classNames.size()]; // output got an array in it, which will contain probabilities of every class

        tflite.run(inputBuffer, output); // running the model

        int predictedClass1Index = getMaxIndex(output[0]);
        int predictedClass2Index = getSecondIndex(output[0], predictedClass1Index);

        float[] hundredpercentchances = output[0];
        Log.i("Chances", Arrays.toString(hundredpercentchances));

        for (float chance : hundredpercentchances) {
            sum += chance;
        }
        double koeff = 100 / sum;
        for (int i = 0; i < hundredpercentchances.length; i++) {
            hundredpercentchances[i] *= (float) koeff; // (float) koeff;
        }
        // so above i just multiplied every of accuracies koeff times so their sum was 100
        // for example if it was [0.1, 0.2, 0.3, 0.4) it will become
        // (10, 20, 30, 40) which looks better
        // idk why do my model work like that and return small accuracies

        double chances1 = (double) ((int) (hundredpercentchances[predictedClass1Index] * 10)) / 10;
        double chances2 = (double) ((int) (hundredpercentchances[predictedClass2Index] * 10)) / 10;
        String predictedClass1 = classNames.get(predictedClass1Index);
        String predictedClass2 = classNames.get(predictedClass2Index);
        if (predictedClass1.equals("notafungus")) {
            textView.setText("Can't recognize a mushroom");
        } else if (!predictedClass1.equals("notafungus") && predictedClass2.equals("notafungus")) {
            textView.setText(predictedClass1 + " - " + chances1 + "%");
        } else {
            textView.setText(predictedClass1 + " - " + chances1 + "%\n" + predictedClass2 + " - " + chances2 + "%");
        }
    }
}